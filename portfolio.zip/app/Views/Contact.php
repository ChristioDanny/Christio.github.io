<!-- Kontak Section -->
<section class="py-5">
  <div class="container">
    <h2 class="mb-4 text-center">Hubungi Saya</h2>
    <div class="row justify-content-center">
      <div class="col-md-8">
        <p class="text-center">Silakan hubungi saya melalui form di bawah ini atau lewat media sosial.</p>

        <form>
          <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" class="form-control" id="nama" placeholder="Nama Anda">
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" placeholder="email@contoh.com">
          </div>
          <div class="mb-3">
            <label for="pesan" class="form-label">Pesan</label>
            <textarea class="form-control" id="pesan" rows="4" placeholder="Tulis pesan Anda..."></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Kirim</button>
        </form>

        <hr class="my-5">

        <div class="text-center">
          <p>Email: <a href="mailto:dannyambarita7@gmail.com">dannyambarita7@gmail.com</a></p>
          <p>LinkedIn: <a href="https://www.linkedin.com/in/danny-ambarita/" target="_blank">linkedin.com/in/danny-ambarita/</a></p>
          <p>GitHub: <a href="https://github.com/christio" target="_blank">github.com/christio</a></p>
        </div>
      </div>
    </div>
  </div>
</section>
