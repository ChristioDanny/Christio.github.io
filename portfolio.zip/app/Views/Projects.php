<!-- Halaman Proyek -->
<section class="py-5">
  <div class="container">
    <h2 class="mb-4 text-center">Proyek Saya</h2>
    <div class="row g-4">

      <!-- Proyek 1 -->
      <div class="col-md-4">
        <div class="card h-100 shadow-sm">
          <img src="https://via.placeholder.com/400x200" class="card-img-top" alt="Project 1">
          <div class="card-body">
            <h5 class="card-title">Sistem Manajemen Inventaris</h5>
            <p class="card-text">Aplikasi web untuk mencatat dan melacak stok barang menggunakan CodeIgniter dan MySQL.</p>
          </div>
        </div>
      </div>

      <!-- Proyek 2 -->
      <div class="col-md-4">
        <div class="card h-100 shadow-sm">
          <img src="https://via.placeholder.com/400x200" class="card-img-top" alt="Project 2">
          <div class="card-body">
            <h5 class="card-title">Website Portofolio</h5>
            <p class="card-text">Situs pribadi yang menampilkan informasi diri, skill, dan proyek-proyek saya sebagai web developer.</p>
          </div>
        </div>
      </div>

      <!-- Proyek 3 -->
      <div class="col-md-4">
        <div class="card h-100 shadow-sm">
          <img src="https://via.placeholder.com/400x200" class="card-img-top" alt="Project 3">
          <div class="card-body">
            <h5 class="card-title">CRUD Data Mahasiswa</h5>
            <p class="card-text">Aplikasi sederhana untuk melakukan input, edit, hapus, dan tampilkan data mahasiswa dengan tampilan user-friendly.</p>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>
