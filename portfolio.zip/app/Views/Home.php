<!-- Hero Section -->
<section class="py-5 bg-light text-center">
  <div class="container">
    <h1 class="display-4 fw-bold">Halo, saya Christio Danny Gratia Ambarita</h1>
    <p class="lead mt-3">Saya adalah seorang Web Developer yang suka membangun aplikasi web modern & efisien.</p>
    <a href="/projects" class="btn btn-primary btn-lg mt-3">Lihat Proyek Saya</a>
  </div>
</section>
