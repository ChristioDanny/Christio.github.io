<!-- Tentang Saya Section -->
<section class="py-5">
  <div class="container">
    <h2 class="mb-4">Tentang Saya</h2>
    <div class="row">
      <div class="col-md-4 text-center mb-4">
        <img src="https://via.placeholder.com/200" class="img-fluid rounded-circle shadow" alt="Foto Profil">
      </div>
      <div class="col-md-8">
        <p>Halo! Saya <strong>Christio Danny Gratia Ambarita</strong>, lulusan Teknik Informatika ITERA 2024. Saya berpengalaman membuat aplikasi web lokal menggunakan PHP dan CodeIgniter, termasuk setup database, CRUD, serta logika backend.</p>
        <p>Saya sangat tertarik mengembangkan aplikasi yang cepat, bersih, dan mudah digunakan. Saat ini saya sedang membangun portofolio pribadi untuk mendemonstrasikan skill saya dalam pengembangan web.</p>
        <p>Di waktu luang, saya suka main Genshin Impact dan nge-build karakter favorit saya! 🎮</p>
      </div>
    </div>
  </div>
</section>
