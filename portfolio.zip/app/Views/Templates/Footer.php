<!-- Footer -->
<footer class="bg-dark text-white text-center py-3 mt-5 mt-auto">
  <p class="mb-0">© <?= date('Y') ?> Christio. Dibuat dengan ❤️ dan CodeIgniter.</p>
</footer>

</div> <!-- Wrapper selesai -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
