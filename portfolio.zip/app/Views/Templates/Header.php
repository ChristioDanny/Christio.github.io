<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= $title ?? 'Portofolio Christio' ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="icon" href="<?= base_url('favicon.png') ?>" type="image/x-icon">

</head>
<body>
<div class="d-flex flex-column min-vh-100"> <!-- Wrapper mulai -->
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">Christio</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link <?= uri_string() === '' ? 'active' : '' ?>" href="/">Beranda</a></li>
        <li class="nav-item"><a class="nav-link" href="/about">Tentang Saya</a></li>
        <li class="nav-item"><a class="nav-link" href="/projects">Proyek</a></li>
        <li class="nav-item"><a class="nav-link" href="/contact">Kontak</a></li>
      </ul>
    </div>
  </div>
</nav>
