<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        $data = ['title' => 'Beranda - Christio'];

        echo view('templates/header', $data);
        echo view('home');
        echo view('templates/footer');
    }

    public function about()
{
    $data = ['title' => 'Tentang Saya - Christio'];
    
    echo view('templates/header', $data);
    echo view('about');
    echo view('templates/footer');
}

public function contact()
{
    $data = ['title' => 'Kontak - Christio'];
    
    echo view('templates/header', $data);
    echo view('contact');
    echo view('templates/footer');
}

public function projects()
{
    $data = ['title' => 'Proyek - Christio'];
    
    echo view('templates/header', $data);
    echo view('projects');
    echo view('templates/footer');
}


}

